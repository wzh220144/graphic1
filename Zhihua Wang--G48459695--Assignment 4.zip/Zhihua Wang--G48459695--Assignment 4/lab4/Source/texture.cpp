#include "head.h"

GLvoid LoadGLTextures(int id, GLuint *texid) {
	// Load Texture
	AUX_RGBImageRec *texture1;

	texture1 = auxDIBImageLoad(texPath[id]);
	if (!texture1)
	{
		exit(1);
	}

	glGenTextures(1, texid);				// Generate 1 Texture

	// Create Linear Filtered Texture
	glBindTexture(GL_TEXTURE_2D, *texid);
	
		if(id!=3) {

			glEnable(GL_TEXTURE_GEN_S);   // auto texture generation
			glEnable(GL_TEXTURE_GEN_T);		//auto texture generation
			//Set up texture coordinate generation.
			glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
			//glTexGenfv(GL_S, GL_EYE_PLANE, biasMatrix[0]);
			glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
			//glTexGenfv(GL_T, GL_EYE_PLANE, biasMatrix[1]);
			glDisable(GL_TEXTURE_GEN_S);   // close texture generation
			glDisable(GL_TEXTURE_GEN_T);		//close texture generation
		}

		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, texture1->sizeX, texture1->sizeY, 0, GL_RGB, GL_UNSIGNED_BYTE, texture1->data);

	glBindTexture(GL_TEXTURE_2D, 0);
}