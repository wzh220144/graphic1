#include "head.h"

Shader::Shader() {
	glDeleteProgram(program);
	glDeleteShader(vertHandle);
	glDeleteShader(fragHandle);
}

Shader::~Shader() {
	glDeleteProgram(program);
	glDeleteShader(vertHandle);
	glDeleteShader(fragHandle);
}

void Shader::loadShader(GLchar* vertName, GLchar* fragName) {
	
	//create shader hadle
	vertHandle=glCreateShader(GL_VERTEX_SHADER);
	fragHandle=glCreateShader(GL_FRAGMENT_SHADER);
	if(vertHandle==NULL) {
		printf("ERROR: create vertex handle failed\n");
		exit(1);
	}
	if(fragHandle==NULL) {
		printf("ERROR: create fragment handle failed\n");
		exit(1);
	}

	//read shader source and attach source to shader handle
	GLchar *shaderSource=readFile(vertName);
	glShaderSource(vertHandle, 1, (const GLchar **) &shaderSource, NULL);
	free(shaderSource);
	shaderSource=readFile(fragName);
	glShaderSource(fragHandle, 1, (const GLchar **) &shaderSource, NULL);
	free(shaderSource);

	//compile shader
	glCompileShader(vertHandle);
	glCompileShader(fragHandle);
	glGetShaderiv(vertHandle, GL_COMPILE_STATUS, &status);
	if(status!=GL_TRUE) {
		printf("ERROR: vertex handle compilation is wrong!\n");
		shaderLog(vertHandle);
		exit(1);
	}
	glGetShaderiv(fragHandle, GL_COMPILE_STATUS, &status);
	if(status!=GL_TRUE) {
		printf("ERROR: fragment handle compilation is wrong!\n");
		shaderLog(fragHandle);
		exit(1);
	}

	//attach shader to program object
	program = glCreateProgram();
	glAttachShader(program, vertHandle);
	glAttachShader(program, fragHandle);
	
	//link the program object
	glLinkProgram(program);
	glGetProgramiv(program, GL_LINK_STATUS, &status);
	if(status!=GL_TRUE) {
		printf("ERROR: program link is wrong!\n");
		programLog();
		exit(1);
	}

	texIDLoc = glGetUniformLocation(program, "textureID");
	tangLoc = glGetAttribLocation(program, "Tangent");

}

void Shader::shaderLog(GLuint Handle) {
	GLint length;
	GLsizei num;
	char *log;
	glGetShaderiv(Handle, GL_INFO_LOG_LENGTH, &length);
	if(length>0) {
		log = new char[length+1];
		log[length]=0;
		glGetShaderInfoLog(Handle, length, &num, log);
		printf("%s\n", log);
	}
}

void Shader::programLog() {
	GLint length;
	GLsizei num;
	char *log;
	glGetProgramiv(program, GL_INFO_LOG_LENGTH, &length);
	if(length>0) {
		log = new char[length+1];
		log[length]=0;
		glGetProgramInfoLog(program, length, &num, log);
		printf("%s\n", log);
	}
}

void Shader::useShader() {
	glUseProgram(program);
}

void Shader::closeShader() {
	glUseProgram(0);
}

void Shader::delShader() {
	glDeleteProgram(program);
	glDeleteShader(vertHandle);
	glDeleteShader(fragHandle);
}