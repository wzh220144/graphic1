#include "head.h"

GLchar *readFile(const char *filename) {
	
	FILE *fp;
	GLchar *content = NULL;
	GLint count=0;

	if(filename==NULL) {
		printf("ERROR: file does not exist!\n");
		exit(1);
	}

	fp=fopen(filename, "rt");
	if(fp==NULL) {
		printf("ERROR: %s does not exist!\n", filename);
		exit(1);
	}

	fseek(fp, 0, SEEK_END);
	count=ftell(fp);
	rewind(fp);

	if(count<=0) {
		printf("ERROR: %s does not have code!\n", filename);
		exit(1);
	}
	
	content=new char[count+1];
	count=fread(content, sizeof(char), count, fp);
	content[count]=0;

	fclose(fp);

	return content;

}