#ifndef __GWU_HELPER__
#define __GWU_HELPER__

void DrawGrids( void );

#endif // __GWU_HELPER__