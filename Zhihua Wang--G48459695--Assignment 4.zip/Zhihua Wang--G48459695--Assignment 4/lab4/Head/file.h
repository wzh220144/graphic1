#ifndef __GWU_FILE__
#define __GWU_FILE__

GLchar *readFile(const char *filename);

#endif