#ifndef __GWU_TEXTURE__
#define __GWU_TEXTURE__

GLvoid LoadGLTextures(int id, GLuint *texid);

#endif