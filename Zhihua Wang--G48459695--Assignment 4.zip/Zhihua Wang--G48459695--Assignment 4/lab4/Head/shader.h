#ifndef __GWU_SHADER__
#define __GWU_SHADER__

class Shader {

public:
	int type;
	GLuint vertHandle, fragHandle;
	GLuint program;
	GLint status;
	GLint texIDLoc;
	GLint tangLoc;

public:
	Shader();
	~Shader();
	void loadShader(char *vertName, char *fragName);
	void shaderLog(GLuint Handle);
	void programLog();
	void useShader();
	void delShader();
	void closeShader();

};

#endif