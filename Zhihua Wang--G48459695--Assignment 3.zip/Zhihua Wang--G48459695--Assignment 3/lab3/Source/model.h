#ifndef __GWU_MODEL__
#define __GWU_MODEL__

//================================
// ModelFace
//================================
class ModelFace {
public :
	int		numSides;
	int *	indices;

public :
	ModelFace() {
		numSides = 0;
		indices = NULL;
	}

	~ModelFace() {
		if ( indices ) {
			delete[] indices;                                                                                                                                                                                                                                                                                                                                                                                                  
			indices = NULL;
		}
		numSides = 0;
	}
};

//================================
// Model
//================================
class Model {

public :
	int			numVerts;
	int			numFaces;
	int ID;		//model index
	vec3 *		verts;
	vec3*		normalVerts;
	ModelFace *	faces;
	Matrix md_mat;	//model's transformation matrix
	Matrix pj_mat;	//model's projection transformation matrix:if we need projection model separately, we use this matrix 
	

public :

	Model();
	~Model();
	void DrawEdges();
	void Scale(vec3 offset);	// scale model
	void Translate( const vec3 &offset );		//translate model
	void Rotate( float angle, vec3 vector);		//rotate model
	bool LoadModel( const char *mdPath, const char *norPath, const char *texPath, int id);	// load model from .d file
	
};

void Model::DrawEdges() {
	for ( int i = 0; i < numFaces; i++ ) {
		if(ID!=3) {
				glEnable(GL_TEXTURE_GEN_S);   // auto texture generation
				glEnable(GL_TEXTURE_GEN_T);		//auto texture generation
				glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
				glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_SPHERE_MAP);
		}
		if( (ID==3) && ( (i==4)||(i==5) ) )
			glBindTexture(GL_TEXTURE_2D, texture[4]);
		glBegin( GL_POLYGON );
			for ( int k = 0; k < faces[ i ].numSides; k++ ) {
				int p0 = faces[ i ].indices[ k ];
				if(ID==3) {
					glTexCoord2f(textureVerts[i][k].x, textureVerts[i][k].y);
				}
				
				glNormal3fv( normalVerts[p0].ptr() );
				glVertex3fv( verts[ p0 ].ptr() );
			}
		if( (ID==3) && ( (i==4)||(i==5) ) )
			glBindTexture(GL_TEXTURE_2D, texture[ID]);
		glEnd();
		if(ID!=3) {
				glDisable(GL_TEXTURE_GEN_S);   // auto texture generation
				glDisable(GL_TEXTURE_GEN_T);		//auto texture generation

		}
	}
}

Model::Model() {
	numVerts = 0;
	numFaces = 0;
	verts = NULL;
	normalVerts=NULL;
	//textureVerts=NULL;
	faces = NULL;

	md_mat.init();
	pj_mat.init();
}

Model::~Model() {
	if ( verts ) {
		delete[] verts;
		verts = NULL;
	}
	if(normalVerts) {
		delete[] normalVerts;
		normalVerts=NULL;
	}
	if(textureVerts) {
		delete[] textureVerts;
		textureVerts;
	}
	if ( faces ) {
		delete[] faces;
		faces = NULL;
	}

	numVerts = 0;
	numFaces = 0;
}

	// scale model
void Model::Scale(vec3 offset) {
	Matrix temp;
	temp.init();
	temp.mat[0]=offset.x;
	temp.mat[5]=offset.y;
	temp.mat[10]=offset.z;
	md_mat.MultiMatrix(temp);
}

void Model::Translate( const vec3 &offset ) {
	Matrix temp;
	temp.init();
	temp.mat[12]=offset.x;
	temp.mat[13]=offset.y;
	temp.mat[14]=offset.z;
	md_mat.MultiMatrix(temp);
}

void Model::Rotate( float angle, vec3 vector) {
	vector.normalize();
	float d=sqrt(vector.y*vector.y+vector.z*vector.z);
	Matrix m1, m2, m3, m4;
	m1.init(), m2.init(), m3.init(), m4.init();

	if(d>=1e-10) {
		m4.mat[5]=vector.z/d;
		m4.mat[6]=vector.y/d;
		m4.mat[9]=-vector.y/d;
		m4.mat[10]=vector.z/d;
		m3.mat[0]=d;
		m3.mat[2]=vector.x;
		m3.mat[8]=-vector.x;
		m3.mat[10]=d;
		m1.mat[5]=m4.mat[5];
		m1.mat[6]=-m4.mat[6];
		m1.mat[9]=-m4.mat[9];
		m1.mat[10]=m4.mat[10];
		m2.mat[0]=m3.mat[0];
		m2.mat[2]=-m3.mat[2];
		m2.mat[8]=-m3.mat[8];
		m2.mat[10]=m3.mat[10];
		m3.MultiMatrix(m4);
		m1.MultiMatrix(m2);
		m2.init();
		m2.mat[0]=cos(angle);
		m2.mat[4]=-sin(angle);
		m2.mat[1]=sin(angle);
		m2.mat[5]=cos(angle);
		m1.MultiMatrix(m2);
		m1.MultiMatrix(m3);
		md_mat.MultiMatrix(m1);
	}

	else {
		m3.mat[0]=d;
		m3.mat[2]=vector.x;
		m3.mat[8]=-vector.x;
		m3.mat[10]=d;

		m1.mat[0]=m3.mat[0];
		m1.mat[2]=-m3.mat[2];
		m1.mat[8]=-m3.mat[8];
		m1.mat[10]=m3.mat[10];

		m2.mat[0]=cos(angle);
		m2.mat[4]=-sin(angle);
		m2.mat[1]=sin(angle);
		m2.mat[5]=cos(angle);

		m1.MultiMatrix(m2);
		m1.MultiMatrix(m3);
		md_mat.MultiMatrix(m1);
	}
}

	// load model from .d file
bool Model::LoadModel( const char *mdPath, const char *norPath, const char *texPath, int id) {
		
	ID=id;
	if ( (mdPath==NULL) || (norPath==NULL) || (texPath==NULL) )
		return false;

	FILE *mdFp = fopen(mdPath, "r" ), *norFp = fopen(norPath, "r")/*, *texFp = fopen(texPath, "r")*/;			// open file
	if ( (mdFp==NULL) ||(norFp==NULL) /*||(texFp==NULL)*/  )
		return false;

	fscanf( mdFp, "data%d%d", &numVerts, &numFaces );	// num of vertices and indices

	// alloc vertex normal, vertex and index buffer
	verts = new vec3[ numVerts ];
	normalVerts = new vec3[numVerts];
	//textureVerts = new vec3[numVerts];
	faces = new ModelFace[ numFaces ];
		

	// read vertices
	for ( int i = 0; i < numVerts; i++ ) {
		fscanf( mdFp, "%f%f%f", &verts[ i ].x, &verts[ i ].y, &verts[ i ].z );
		fscanf(norFp, "%f%f%f", &normalVerts[i].x, &normalVerts[i].y, &normalVerts[i].z);
		//fscanf(texFp, "%f%f%f", &textureVerts[i].x, &textureVerts[i].y, &textureVerts[i].z);
	}

	// read indices
	for ( int i = 0; i < numFaces; i++ ) {
		ModelFace *face = &faces[ i ];
		fscanf( mdFp, "%i", &face->numSides );
		faces[ i ].indices = new int[ face->numSides ];
		for( int k = 0; k < face->numSides; k++ )
			fscanf( mdFp, "%i", &face->indices[ k ] );
	}

	// close file
	fclose( mdFp );
	fclose(norFp);
	//fclose(texFp);

	return true;
}


#endif // __GWU_MODEL__