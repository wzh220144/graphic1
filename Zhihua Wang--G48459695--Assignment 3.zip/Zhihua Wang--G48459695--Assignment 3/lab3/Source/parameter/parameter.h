#ifndef __GWU_PARAMETER__
#define __GWU_PARAMETER__

//================================
// global variables
//================================



const float PI=cos(-1.0);	//set PI
const float shitf=0.01;	//the shift of every movement of item and camera 

bool curMouseFlag=false;	//sign that if the left mouse has been clicked
int g_frameIndex;	//frame index
int g_mdCtrl = 0;	// the index of the current model controled
int winXaxis=100, winYaxis=100;	//window position
float temp[16];	//temp for saving modelview matrix 
float winWidth=600.0, winHeight=600.0;	//window size
float Theta=20.0f, Dnear=0.01f, Dfar=100.0f;	//perspective parameter theta, aspect, dnear, dfar


vec3 curMouse;		//the postion of current mouse
Model *g_model;	// model
Camera *g_camera;	//camera of every model
Camera globalCamera;	//global camera
Matrix *globalProjection;	//global projection matrix


//path of model
char g_mdPath[MODEL_NUM][20]={"Data/car.d", "Data/shuttle.d", "Data/cow.d", "Data/walls.d"};

//path of file that contain the normal vector of every vertex of a model
char g_mdNorPath[MODEL_NUM][20]={"Data/carNor.d", "Data/shuttleNor.d", "Data/cowNor.d", "Data/wallsNor.d"};

//path of file that contain the texture postion of every vertex of a model
char g_mdTexPath[MODEL_NUM][20]={"Data/carTex.d", "Data/shuttleTex.d", "Data/cowTex.d", "Data/wallsTex.d"};


//path of texture
char texPath[MODEL_NUM+10][20]={"Picture/shuttle.bmp", "Picture/shuttle.bmp", "Picture/cow.bmp",
																	"Picture/walls.bmp", "Picture/ceiling.bmp"};
//words printed on the screen
char hit[10][200]=
	{"Using j, k, l, u, I, o we can control the position that camera looks at. \n", 
	"Using w, a, s, d, q, e we can control camera��s position.\n",
	"Using up, down, right, left arrow we can control model.\n",
	"Using f, g, h, r, t, y we can rotate the world. \n",
	"Using mouse we can rotate item along with the mouse move direction around y axis. When click left mouse, item start rotating; when release the click, stop rotating.\n"
	};




//light color
float lightColor[LIGHT_NUM][4]={ {0.5f, 0.5f, 0.5f, 0.3f}, 
																{0.8f, 0.4f, 0.7f, 0.4f}, 
																{0.1f, 0.3f, 0.44f, 0.2f} };
//light position
float lightPos[LIGHT_NUM][4]={  {0.0f, -5.0f, 2.0f, 1.0f}, 
																{0.0f, 7.0f, 2.0f, 1.0f}, 
																{-10.0f, -5.0f, -30.0f, 1.0f}, 
																{10.0f, 7.0f, -30.0f, 1.0f}, 
																{10.0f, 5.0f, -50.0f, 1.0f}, 
																{-10.0f, -5.0f, -50.0f, 1.0f} };

//eye, center and up vector of evey camera
vec3 g_cmVector[MODEL_NUM][3]={ {vec3(2.0,2.0,2.0), vec3(0.0, 0.0, 0.0), vec3(0.0, 1.0, 0.0) }, 
																	{vec3(2.0,2.0,2.0), vec3(0.0, 0.0, 0.0), vec3(0.0, 1.0, 0.0) }, 
																	{vec3(2.0,2.0,2.0), vec3(0.0, 0.0, 0.0), vec3(0.0, 1.0, 0.0) }, 
																	{vec3(2.0,2.0,2.0), vec3(0.0, 0.0, 0.0), vec3(0.0, 1.0, 0.0) }
																	};

//eye, center and up vector of global camera
vec3 globalVector[3]={vec3(0.0, 0.0, 0), vec3(0.0, 0.0, -1.0), vec3(0.0, 1.0, 0.0)};

float biasMatrix[4][4]={ {0.5f, 0.0f, 0.0f, 0.0f},
													{0.0f, 0.5f, 0.0f, 0.0f},
													{0.0f, 0.0f, 0.5f, 0.0f},
													{0.5f, 0.5f, 0.5f, 1.0f} };

#endif