#include "stdafx.h"

// standard
#include <cstdio>
#include <iostream>
using namespace std;
#include <sys/stat.h>
#include <fstream>
#include <cstring>
#include <string>
#include <algorithm>
#include <math.h>
#include <cmath>
#include <ctime>
#include <cstdlib>
#include <cassert>

// glut
#include <GL/glut.h>
#include <GL/GL.h>
#include <GL/GLU.h>
#include <GL/GLAUX.H>


#define MODEL_NUM 4	//number of models
#define LIGHT_NUM 10	//number of light source

GLuint texture[MODEL_NUM];		// Storage for 1 textures
//color of model
float g_mdColor[MODEL_NUM][4]={0.3, 0.3, 0.9, 0.24, 
																0.6, 0.7, 0.0, 0.45, 
																0.4, 0.5, 0.1, 1.0,
																1.0, 0.5, 0.4, 1.0
															};




// source
#include <math/matrix.h>
#include <math/vec3.h>
#include <math/operation.h>
#include <math/projection.h>
#include <model.h>
#include <camera.h>
#include <parameter/parameter.h>
#include <texture.h>
#include <helper.h>

vec3 camera_pos=vec3(0,0,0);

//================================
// routine for recovering modelview matrix for evey model
//================================
void Recover_Matr(int id) {
	glMatrixMode( GL_MODELVIEW );
	glLoadMatrixf(MultiMatrix(globalCamera.cm_mat, g_model[id].md_mat));
}

void Recover_Global() {
	glMatrixMode( GL_MODELVIEW );
	glLoadMatrixf(globalCamera.cm_mat.mat);
}

//================================
//collect memory
//================================

void close() {

	//collect memory
	delete[] g_model;
	g_model=NULL;
	delete[] g_camera;
	g_camera = NULL;
	delete globalProjection;
	globalProjection = NULL;

	//disable all light
	glDisable(GL_LIGHT0);
	glDisable(GL_LIGHT1);
	glDisable(GL_LIGHT2);
	glDisable(GL_LIGHT3);
	glDisable(GL_LIGHT4);
	glDisable(GL_LIGHT5);
	glDisable(GL_LIGHTING);

	//disable depth test
	glDisable(GL_DEPTH_TEST);

	//do not remove backface
	glDisable(GL_CULL_FACE);

	//cancel the function that normalize the normal vector
	glDisable(GL_NORMALIZE);

	glDisable(GL_COLOR_MATERIAL);		//close item material
	glDisable(GL_BLEND);		//close color blend

}

//================================
// init
//================================
void init( void ) {

	srand(time(NULL));
	for(int i=0; i<6;i++) {
		printf("%s", hit[i]);
	}

	//init projection and camera
	g_mdCtrl=0;
	g_model = new Model[MODEL_NUM];
	g_camera = new Camera[MODEL_NUM];
	globalProjection =new Matrix;
	globalProjection->init();
	globalCamera.setLookAt(globalVector[0], globalVector[1], globalVector[2], -1);
	globalCamera.Translate(vec3(0.0, 0.0, -9.0));

	//remove backface
	glEnable(GL_CULL_FACE);

	//make all the normal vector normal
	glEnable(GL_NORMALIZE);

	//render with linear color
	glShadeModel(GL_SMOOTH);
	
	//fill the frontface and backface of a polygon
	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);

	//if define the order of the vertexes of a polygon counterclockwise, then this face is front 
	glFrontFace(GL_CCW);
	

	// enable depth test
	glEnable( GL_DEPTH_TEST );
	
	//start light souce
	glEnable(GL_LIGHTING);
	glLightModeli(GL_LIGHT_MODEL_TWO_SIDE, GL_TRUE);
	//light source 1
	glLightfv(GL_LIGHT0, GL_POSITION, lightPos[0]);   
	glLightfv(GL_LIGHT0, GL_AMBIENT,  lightColor[0]); 
	glLightfv(GL_LIGHT0, GL_DIFFUSE,  lightColor[1]); 
	glLightfv(GL_LIGHT0, GL_SPECULAR, lightColor[2]);

	//light source 2
	glLightfv(GL_LIGHT1, GL_POSITION, lightPos[1]);   
	glLightfv(GL_LIGHT1, GL_AMBIENT,  lightColor[0]); 
	glLightfv(GL_LIGHT1, GL_DIFFUSE,  lightColor[1]); 
	glLightfv(GL_LIGHT1, GL_SPECULAR, lightColor[2]);

	//light source 3
	glLightfv(GL_LIGHT2, GL_POSITION, lightPos[2]);   
	glLightfv(GL_LIGHT2, GL_AMBIENT,  lightColor[0]); 
	glLightfv(GL_LIGHT2, GL_DIFFUSE,  lightColor[1]); 
	glLightfv(GL_LIGHT2, GL_SPECULAR, lightColor[2]);

	//light source 4
	glLightfv(GL_LIGHT3, GL_POSITION, lightPos[3]);   
	glLightfv(GL_LIGHT3, GL_AMBIENT,  lightColor[0]); 
	glLightfv(GL_LIGHT3, GL_DIFFUSE,  lightColor[1]); 
	glLightfv(GL_LIGHT3, GL_SPECULAR, lightColor[2]);

	//light source 5
	glLightfv(GL_LIGHT4, GL_POSITION, lightPos[4]);   
	glLightfv(GL_LIGHT4, GL_AMBIENT,  lightColor[0]); 
	glLightfv(GL_LIGHT4, GL_DIFFUSE,  lightColor[1]); 
	glLightfv(GL_LIGHT4, GL_SPECULAR, lightColor[2]);

	//light source 6
	glLightfv(GL_LIGHT5, GL_POSITION, lightPos[5]);   
	glLightfv(GL_LIGHT5, GL_AMBIENT,  lightColor[0]); 
	glLightfv(GL_LIGHT5, GL_DIFFUSE,  lightColor[1]); 
	glLightfv(GL_LIGHT5, GL_SPECULAR, lightColor[2]);

	//turn on all the light source
	glEnable(GL_LIGHT0);
	glEnable(GL_LIGHT1);
	glEnable(GL_LIGHT2);
	glEnable(GL_LIGHT3);
	glEnable(GL_LIGHT4);
	glEnable(GL_LIGHT5);

	//init texture
	glEnable(GL_TEXTURE_2D);
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);	// Really Nice Perspective Calculations

	//semi-transparent
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);		// Set The Blending Function For Translucency

	//init material
	glEnable(GL_COLOR_MATERIAL);
	glColorMaterial(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE);
	glMaterialfv(GL_FRONT_AND_BACK,GL_SPECULAR, lightColor[2]);
	glMateriali(GL_FRONT_AND_BACK,GL_SHININESS,128);

	// load
	for(int i=0; i<MODEL_NUM;i++) {
		LoadGLTextures(i, i);
		g_model[i].LoadModel( g_mdPath[i], g_mdNorPath[i], g_mdTexPath[i], i);
		switch(i) {
		case 0:
			g_model[i].Scale(vec3(1.0, 1.0, 1.0));
			g_model[i].Translate(vec3(-3.0, 0.0, 0.0));
			break;
		case 1:
			g_model[i].Scale(vec3(1.0, 1.0, 1.0));
			g_model[i].Translate(vec3(0.0, 0.0, 0.0));
			break;
		case 2:
			g_model[i].Scale(vec3(1.0, 1.0, 1.0));
			g_model[i].Translate(vec3(3.0, 0.0, 0.0));
			break;
		case 3:
			g_model[i].Scale(vec3(5.0, 5.0, 5.0));
		default:
			break;
		}
	}
	LoadGLTextures(4, 4);

}

//================================
// update
//================================
void update( void ) {
	// do something before rendering...
}

//================================
// render
//================================
void render( void ) {

	// clear color and depth buffer
	glClearColor (0.0, 0.0, 0.0, 1.0);
	glClearDepth ( 1.0 );
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);	

	// draw model
	for(int i=0; i<MODEL_NUM; i++) {

		glBindTexture(GL_TEXTURE_2D, texture[i]);
			//glColor4f( g_mdColor[i][0], g_mdColor[i][1], g_mdColor[i][2], g_mdColor[i][3]);
			Recover_Matr(i);
			g_model[i].DrawEdges();
		glBindTexture(GL_TEXTURE_2D, 0);

	}

	// swap back and front buffers
	glutSwapBuffers();
}

//================================
// mouse input
//================================

void mouse_press(GLint button, GLint action, GLint xMouse, GLint yMouse) {
	
	if( (button==GLUT_LEFT_BUTTON) && (action==GLUT_DOWN)) {
		curMouseFlag=true;
		curMouse.x=(float)xMouse, curMouse.y=(float)yMouse, curMouse.z=0.0;
	}

	else if((button==GLUT_LEFT_BUTTON) && (action==GLUT_UP)) {
		curMouseFlag=false;
	}

}

void mouse_move(GLint xMouse, GLint yMouse) {

	if(curMouseFlag) {
			vec3 a;
			a.x=(float)xMouse, a.y=(float)yMouse, a.z=0.0;
			g_model[g_mdCtrl].Rotate(a.dot(curMouse)/a.magnitude()/curMouse.magnitude(), vec3(0.0, 1.0, 0.0));
			curMouse.x=(float)xMouse, curMouse.y=(float)yMouse, curMouse.z=0.0;
	}

}


void key_press( unsigned char key, int x, int y ) {
	switch (key) {

	//camera translate
	case 'w':		// up
		globalCamera.Translate(vec3(0, shitf, 0));
		camera_pos=vec3(0, 0, 0)*globalCamera.cm_mat;
		//if( (camera_pos.x<=-5.0) || (camera_pos.x>=5.0) || (camera_pos.y<=-5.0) || (camera_pos.x>=5.0) || (camera_pos.z<=-5.0) || (camera_pos.z>=5.0) ) {
			//globalCamera.Translate(vec3(0, -shitf, 0));
		//}
		break;
	case 'a':		// left
		globalCamera.Translate(vec3(-shitf, 0, 0));
		camera_pos=vec3(0, 0, 0)*globalCamera.cm_mat;
		//if( (camera_pos.x<=-5.0) || (camera_pos.x>=5.0) || (camera_pos.y<=-5.0) || (camera_pos.x>=5.0) || (camera_pos.z<=-5.0) || (camera_pos.z>=5.0) ) {
		//	globalCamera.Translate(vec3(shitf, 0, 0));
	//	}
		break;
	case 's':		// down
		globalCamera.Translate(vec3(0, -shitf, 0));
		camera_pos=vec3(0, 0, 0)*globalCamera.cm_mat;
		//if( (camera_pos.x<=-5.0) || (camera_pos.x>=5.0) || (camera_pos.y<=-5.0) || (camera_pos.x>=5.0) || (camera_pos.z<=-5.0) || (camera_pos.z>=5.0) ) {
		//	globalCamera.Translate(vec3(0, shitf, 0));
		//}
		break;
	case 'd':		//right
		globalCamera.Translate(vec3(shitf, 0, 0));
		camera_pos=vec3(0, 0, 0)*globalCamera.cm_mat;
	//	if( (camera_pos.x<=-5.0) || (camera_pos.x>=5.0) || (camera_pos.y<=-5.0) || (camera_pos.x>=5.0) || (camera_pos.z<=-5.0) || (camera_pos.z>=5.0) ) {
	//		globalCamera.Translate(vec3(-shitf, 0, 0));
		//}
		break;
	case 'q':	//forward
		globalCamera.Translate(vec3(0, 0, shitf));
		camera_pos=vec3(0, 0, 0)*globalCamera.cm_mat;
		//if( (camera_pos.x<=-5.0) || (camera_pos.x>=5.0) || (camera_pos.y<=-5.0) || (camera_pos.x>=5.0) || (camera_pos.z<=-5.0) || (camera_pos.z>=5.0) ) {
		//	globalCamera.Translate(vec3(0, 0, -shitf));
	//	}
		break;
	case 'e':	//backward
		globalCamera.Translate(vec3(0, 0, -shitf));
		camera_pos=vec3(0, 0, 0)*globalCamera.cm_mat;
	//	if( (camera_pos.x<=-5.0) || (camera_pos.x>=5.0) || (camera_pos.y<=-5.0) || (camera_pos.x>=5.0) || (camera_pos.z<=-5.0) || (camera_pos.z>=5.0) ) {
		//	globalCamera.Translate(vec3(0, 0, shitf));
	//	}
		break;

	//camera rotate
	case 'j'://y clockwise
		globalCamera.antiRotate(shitf, vec3(0, 0.1, 0));
		camera_pos=vec3(0, 0, 0)*globalCamera.cm_mat;
	//	if( (camera_pos.x<=-5.0) || (camera_pos.x>=5.0) || (camera_pos.y<=-5.0) || (camera_pos.x>=5.0) || (camera_pos.z<=-5.0) || (camera_pos.z>=5.0) ) {
	//		globalCamera.antiRotate(-shitf, vec3(0, 0.1, 0));
	//	}
		break;
	case 'l':////y counterclockwise
		globalCamera.antiRotate(-shitf, vec3(0, 0.1, 0));
		camera_pos=vec3(0, 0, 0)*globalCamera.cm_mat;
	//	if( (camera_pos.x<=-5.0) || (camera_pos.x>=5.0) || (camera_pos.y<=-5.0) || (camera_pos.x>=5.0) || (camera_pos.z<=-5.0) || (camera_pos.z>=5.0) ) {
	//		globalCamera.antiRotate(shitf, vec3(0, 0.1, 0));
	//	}
		break;
	case 'i'://z clockwise
		globalCamera.antiRotate(shitf, vec3(0.0, 0, 1.0));
		camera_pos=vec3(0, 0, 0)*globalCamera.cm_mat;
		//if( (camera_pos.x<=-5.0) || (camera_pos.x>=5.0) || (camera_pos.y<=-5.0) || (camera_pos.x>=5.0) || (camera_pos.z<=-5.0) || (camera_pos.z>=5.0) ) {
		//	globalCamera.antiRotate(-shitf, vec3(0.0, 0, 1.0));
	//	}
		break;
	case 'k'://z counterclockwise
		globalCamera.antiRotate(-shitf, vec3(0.0, 0, 1.0));
		camera_pos=vec3(0, 0, 0)*globalCamera.cm_mat;
	//	if( (camera_pos.x<=-5.0) || (camera_pos.x>=5.0) || (camera_pos.y<=-5.0) || (camera_pos.x>=5.0) || (camera_pos.z<=-5.0) || (camera_pos.z>=5.0) ) {
	//		globalCamera.antiRotate(shitf, vec3(0.0, 0, 1.0));
	//	}
		break;
	case 'u'://x clockwise
		globalCamera.antiRotate(shitf, vec3(1.0, 0.0, 0.0));
		camera_pos=vec3(0, 0, 0)*globalCamera.cm_mat;
	//	if( (camera_pos.x<=-5.0) || (camera_pos.x>=5.0) || (camera_pos.y<=-5.0) || (camera_pos.x>=5.0) || (camera_pos.z<=-5.0) || (camera_pos.z>=5.0) ) {
	//		globalCamera.antiRotate(-shitf, vec3(1.0, 0.0, 0.0));
	//	}
		break;
	case 'o'://x counterclockwise
		globalCamera.antiRotate(-shitf, vec3(1.0, 0.0, 0.0));
		camera_pos=vec3(0, 0, 0)*globalCamera.cm_mat;
	//	if( (camera_pos.x<=-5.0) || (camera_pos.x>=5.0) || (camera_pos.y<=-5.0) || (camera_pos.x>=5.0) || (camera_pos.z<=-5.0) || (camera_pos.z>=5.0) ) {
	//		globalCamera.antiRotate(shitf, vec3(1.0, 0.0, 0.0));
	//	}
		break;

		//world rotate
		case 'f'://y clockwise
		globalCamera.Rotate(shitf, vec3(0, 0.1, 0));
		camera_pos=vec3(0, 0, 0)*globalCamera.cm_mat;
	//	if( (camera_pos.x<=-5.0) || (camera_pos.x>=5.0) || (camera_pos.y<=-5.0) || (camera_pos.x>=5.0) || (camera_pos.z<=-5.0) || (camera_pos.z>=5.0) ) {
	//		globalCamera.Rotate(-shitf, vec3(0, 0.1, 0));
	//	}
		break;
	case 'h'://y counterclock
		globalCamera.Rotate(-shitf, vec3(0, 0.1, 0));
		camera_pos=vec3(0, 0, 0)*globalCamera.cm_mat;
		//if( (camera_pos.x<=-5.0) || (camera_pos.x>=5.0) || (camera_pos.y<=-5.0) || (camera_pos.x>=5.0) || (camera_pos.z<=-5.0) || (camera_pos.z>=5.0) ) {
		//	globalCamera.Rotate(shitf, vec3(0, 0.1, 0));
	//	}
		break;
	case 't'://z clockwise
		globalCamera.Rotate(shitf, vec3(0.0, 0, 1.0));
	//	camera_pos=vec3(0, 0, 0)*globalCamera.cm_mat;
		//if( (camera_pos.x<=-5.0) || (camera_pos.x>=5.0) || (camera_pos.y<=-5.0) || (camera_pos.x>=5.0) || (camera_pos.z<=-5.0) || (camera_pos.z>=5.0) ) {
		//	globalCamera.Rotate(-shitf, vec3(0.0, 0, 1.0));
	//	}
		break;
	case 'g'://z counterclockwise
		globalCamera.Rotate(-shitf, vec3(0.0, 0, 1.0));
		camera_pos=vec3(0, 0, 0)*globalCamera.cm_mat;
	//	if( (camera_pos.x<=-5.0) || (camera_pos.x>=5.0) || (camera_pos.y<=-5.0) || (camera_pos.x>=5.0) || (camera_pos.z<=-5.0) || (camera_pos.z>=5.0) ) {
		//	globalCamera.Rotate(shitf, vec3(0.0, 0, 1.0));
	//	}
		break;
	case 'r'://x clockwise
		globalCamera.Rotate(shitf, vec3(1.0, 0.0, 0.0));
		camera_pos=vec3(0, 0, 0)*globalCamera.cm_mat;
	//	if( (camera_pos.x<=-5.0) || (camera_pos.x>=5.0) || (camera_pos.y<=-5.0) || (camera_pos.x>=5.0) || (camera_pos.z<=-5.0) || (camera_pos.z>=5.0) ) {
		//	globalCamera.Rotate(-shitf, vec3(1.0, 0.0, 0.0));
	//	}
		break;
	case 'y'://x counterclockwise
		globalCamera.Rotate(-shitf, vec3(1.0, 0.0, 0.0));
		camera_pos=vec3(0, 0, 0)*globalCamera.cm_mat;
	//	if( (camera_pos.x<=-5.0) || (camera_pos.x>=5.0) || (camera_pos.y<=-5.0) || (camera_pos.x>=5.0) || (camera_pos.z<=-5.0) || (camera_pos.z>=5.0) ) {
	//		globalCamera.Rotate(shitf, vec3(1.0, 0.0, 0.0));
	//	}
		break;

	//change control item
	case '0':
		g_mdCtrl=0;
		break;
	case '1':
		g_mdCtrl=1;
		break;
	case '2':
		g_mdCtrl=2;
		break;

	default:
		return;
    }
	printf("%c\n", key);
}
 
void special_key( int key, int x, int y ) {
	switch (key) {

	case GLUT_KEY_RIGHT: //right arrow, rotate control item with z axis in counterclockwise
		g_model[g_mdCtrl].Rotate(shitf, vec3(0, 0, 1.0));
		printf("key_right\n ");
		break;
	case GLUT_KEY_LEFT: //left arrow, rotate control item with z axis in clockwise
		g_model[g_mdCtrl].Rotate(-shitf, vec3(0, 0, 1.0));
		printf("key_left\n ");
		break;
	case GLUT_KEY_DOWN: //down arrow, scale down the control item 
		g_model[g_mdCtrl].Scale(vec3(0.95, 0.95, 0.95));
		printf("key_down\n ");
		break;
	case GLUT_KEY_UP: //up arrow, scale up the control item 
		g_model[g_mdCtrl].Scale(vec3(1.05, 1.05, 1.05));
		printf("key_up\n ");
		break;
	case GLUT_KEY_PAGE_UP:	//Page Up function key, rotate control item with y axis in counterclockwise
		g_model[g_mdCtrl].Rotate(shitf, vec3(0, 1.0, 0.0));
		printf("key_pageup\n ");
		break;
	case GLUT_KEY_PAGE_DOWN :	//Page Down function key, rotate control item with y axis in clockwise
		g_model[g_mdCtrl].Rotate(-shitf, vec3(0, 1.0, 0.0));
		printf("key_down\n ");
		break;

	default:      
		break;
	}
}

//================================
// reshape : update viewport and projection matrix when the window is resized
//================================
void reshape( int w, int h ) {

	// screen size
	winWidth  = w;
	winHeight = h;	

	glViewport( 0, 0, (GLsizei)winWidth, (GLsizei)winHeight );
	perspective(Theta, (GLfloat)winWidth/(GLfloat)winHeight, Dnear, Dfar, globalProjection);
	
}


//================================
// timer : triggered every 16ms ( about 60 frames per second )
//================================
void timer( int value ) {
	// increase frame index
	g_frameIndex++;

	update();
	
	// render
	glutPostRedisplay();

	// reset timer
	glutTimerFunc( 16, timer, 0 );
}

//================================
// main
//================================
int main( int argc, char** argv ) {
	
	// create opengL window
	glutInit( &argc, argv );
	glutInitDisplayMode( GLUT_DOUBLE | GLUT_RGB |GLUT_DEPTH );
	glutInitWindowSize( (int)winWidth, (int)winHeight ); 
	glutInitWindowPosition( winXaxis, winYaxis);
	glutCreateWindow( argv[0] );

	// init
	init();
	
	// set callback functions
	glutDisplayFunc( render );
	glutReshapeFunc( reshape );
	glutKeyboardFunc( key_press ); 
	glutSpecialFunc( special_key );
	glutTimerFunc( 16, timer, 0 );
	//glutMouseFunc(mouse_press);
	//glutMotionFunc(mouse_move);
	// main loop
	glutMainLoop();

	close();

	return 0;
}