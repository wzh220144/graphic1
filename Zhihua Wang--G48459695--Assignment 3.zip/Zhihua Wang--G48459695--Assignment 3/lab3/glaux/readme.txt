Copiez le fichier dans le r�pertoire de l'application ou dans :
C:\Windows\system (pour Windows 98/Me)
C:\WINNT\system32 (pour Windows 2000/XP)