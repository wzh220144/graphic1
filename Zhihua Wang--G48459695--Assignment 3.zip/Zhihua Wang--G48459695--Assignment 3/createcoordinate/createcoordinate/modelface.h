#ifndef __GWU_MODELFACE__
#define __GWU_MODELFACE__
class ModelFace {
public :
	int		numSides;
	int *	indices;

public :
	ModelFace() {
		numSides = 0;
		indices = NULL;
	}

	~ModelFace() {
		if ( indices ) {
			delete[] indices;                                                                                                                                                                                                                                                                                                                                                                                                  
			indices = NULL;
		}
		numSides = 0;
	}
};

#endif