#include <cstdio>
#include <iostream>
#include <cstring>
#include <cmath>
#include "modelface.h"
#include "matrix.h"
#include "vec3.h"
using namespace std;

#define NUM 1000		//the max number of file
#define LENTH	50		//the max number of filename

char fileName[NUM][LENTH];
char norFileName[NUM][LENTH];
char texFileName[NUM][LENTH];
int N;		//number representing how many file we should read

//calculate the product of a and b
vec3  Xproduct(vec3 a, vec3 b) {
	return vec3(a.y*b.z-a.z*b.y, a.z*b.x-a.x*b.z, a.x*b.y-a.y*b.x);
}

void init() {

	FILE *fp=fopen("data", "r");

	fscanf(fp, "%d", &N);

	for(int i=0; i<N; i++) {
		fscanf(fp, "%s", fileName[i]);
		int l=strlen(fileName[i]);
		l-=2;
		for(int j=0; j<l; j++) {
			norFileName[i][j]=fileName[i][j];
			texFileName[i][j]=fileName[i][j];
		}
		norFileName[i][l]='N';
		norFileName[i][l+1]='o';
		norFileName[i][l+2]='r';
		norFileName[i][l+3]='.';
		norFileName[i][l+4]='d';
		texFileName[i][l]='T';
		texFileName[i][l+1]='e';
		texFileName[i][l+2]='x';
		texFileName[i][l+3]='.';
		texFileName[i][l+4]='d';
	}
	fclose(fp);

}

/*&void caltexil(vec3 *texil, ModelFace *face, vec3 *verts ) {
	int n=face->numSides;
	for(int i=)

}*/

void solve() {

	int numFaces;		// the number of faces
	int numVerts;		//the number of verts
	ModelFace *faces;
	vec3 *verts;
	vec3 *normalVerts;
	vec3 **textureVerts;

	for(int f=0; f<N; f++) {

		FILE *fp=fopen(fileName[f], "r");
		vec3 Max, Min;

		fscanf(fp, "data %d %d", &numVerts, &numFaces);

		verts=new vec3[numVerts];
		normalVerts=new vec3[numVerts];
		//textureVerts=new vec3*[numFaces];
		faces=new ModelFace[numFaces];

		for(int i=0; i<numVerts; i++) {
			fscanf(fp, "%f %f %f", &verts[i].x, &verts[i].y, &verts[i].z);
			normalVerts[i].x=normalVerts[i].y=normalVerts[i].z=0.0;
			if(i==0)
				Max=verts[i], Min=verts[i];
			else {
					Max.x=verts[i].x>Max.x?verts[i].x:Max.x;
					Max.y=verts[i].y>Max.y?verts[i].y:Max.y;
					Max.z=verts[i].z>Max.z?verts[i].z:Max.z;
					Min.x=verts[i].x>Min.x?Min.x:verts[i].x;
					Min.y=verts[i].y>Min.y?Min.y:verts[i].y;
					Min.z=verts[i].z>Min.z?Min.z:verts[i].z;
			}
		}

		vec3 center=(Min+Max)*0.5f;
		vec3 size=(Max-Min)*0.5f;
		float r=size.x;
		if(size.y>r)
			r=size.y;
		if(size.z>r)
			r=size.z;
		if(r>=1e-10)
			r=1.0f/r;
		else r=0.0;

		for(int i=0; i<numVerts; i++) {
			verts[i]=verts[i]-center;
			verts[i]=verts[i]*r;
		}

		for ( int i=0; i<numFaces; i++) {
			ModelFace *face = &faces[ i ];
			vec3 normal;
			normal.x=normal.y=normal.z=0.0;

			fscanf( fp, "%i", &face->numSides );
			faces[ i ].indices = new int[ face->numSides ];
		//	textureVerts[i]=new vec3[face->numSides];

			for ( int k=0; k<face->numSides; k++)
				fscanf( fp, "%i", &face->indices[ k ] );

			int p0=face->indices[0], p1=face->indices[1], p2=face->indices[2];
			normal=Xproduct( ( verts[ p1] - verts[p0] ), ( verts[p2] - verts[p1]));

			//caltexil(textureVerts[i], face, verts, normal);

			for(int j=0; j<face->numSides; j++) {
				int p=face->indices[j];
				normalVerts[p] = normalVerts[p]+normal;
			}

		}

		for(int i=0; i<numVerts; i++)
			normalVerts[i].normalize();

		fclose(fp);

		fp=fopen(fileName[f], "w");
		fprintf(fp, "data %d %d\n", numVerts, numFaces);
		for(int i=0; i<numVerts; i++)
			fprintf(fp, "%f %f %f\n", verts[i].x, verts[i].y, verts[i].z);
		for(int i=0; i<numFaces; i++) {
			fprintf(fp, "%d", faces[i].numSides);
			for(int j=0; j<faces[i].numSides; j++) {
				fprintf(fp, " %d", faces[i].indices[j]);
			}
			fprintf(fp, "\n");
		}
		fclose(fp);

		fp=fopen(norFileName[f], "w");
		for(int i=0; i<numVerts; i++)
			fprintf(fp, "%f %f %f\n", normalVerts[i].x, normalVerts[i].y, normalVerts[i].z);
		fclose(fp);

		delete[] verts;
		delete[] normalVerts;
		//delete[] textureVerts;
		delete[] faces;
		verts=NULL, normalVerts=NULL, /*textureVerts=NULL,*/ faces=NULL;
		numVerts=0;

	}
}

int main () {

	init();
	solve();

	return 0;
}